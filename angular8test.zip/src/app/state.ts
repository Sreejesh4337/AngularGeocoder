export class State {
  City: string;
  State: string;
  District: string;
}
