import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { State } from './state.model';

@Injectable({
  providedIn: 'root'
})
export class StateServiceService {
  url = 'https://indian-cities-api-nocbegfhqg.now.sh/cities';
  constructor(
    private http: HttpClient
  ) { }

  getStatesLists(): Observable<State[]> {
    return this.http.get<any>(this.url);
  }

  getDistrictList(district: string): Observable<State[]> {
    return this.http.get<any>(this.url + '?State=' + district);
  }
}
